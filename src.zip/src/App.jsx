import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import LandingPage from "./pages/LandingPage";
import ServiceCard from "./pages/ServiceCard"; // Adjust path if necessary
import "./styles.css";
import ProfilePage from "./pages/ProfilePage";
import PainMapper from "./pages/PainMapper";
import SkinDiseaseDetection from "./pages/SkinDeceaseDetection";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/services" element={<ServiceCard />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/painmapper" element={<PainMapper />} />
        <Route path="/skin-detection" element={<SkinDiseaseDetection/>} />
      </Routes>
    </Router>
  );
}

export default App;